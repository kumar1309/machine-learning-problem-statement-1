from flask import Flask, request, jsonify, render_template, send_file, redirect, url_for
import os
from werkzeug.utils import secure_filename
from PIL import Image
import numpy as np
import tensorflow as tf
from tensorflow.keras.applications import EfficientNetB0
from tensorflow.keras.preprocessing import image as keras_image
from tensorflow.keras.applications.efficientnet import preprocess_input, decode_predictions
from groq import Groq

# Initialize Flask app
app = Flask(__name__)


# Configuration
UPLOAD_FOLDER = 'uploads'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg', 'gif'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

# Ensure the upload folder exists
if not os.path.exists(UPLOAD_FOLDER):
    os.makedirs(UPLOAD_FOLDER)

# Load pre-trained EfficientNetB0 model for image recognition
model = EfficientNetB0(weights='imagenet')

# Initialize Groq client
client = Groq(api_key="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")

def allowed_file(filename):
    """Check if the file has an allowed extension."""
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

def predict_disease(img_path):
    """Predict the disease from the image using the pre-trained model."""
    img = keras_image.load_img(img_path, target_size=(224, 224))
    x = keras_image.img_to_array(img)
    x = np.expand_dims(x, axis=0)
    x = preprocess_input(x)
    preds = model.predict(x)
    decoded = decode_predictions(preds, top=3)[0]
    predictions = [{"label": label, "description": desc, "probability": float(prob)} for (label, desc, prob) in decoded]
    return predictions

def disease_management(disease_desc):
    """Return management advice based on disease prediction."""
    if "fever" in disease_desc:
        return "For fever, rest and stay hydrated. If the fever persists, consult a doctor."
    elif "cough" in disease_desc:
        return "For a cough, take cough syrups and stay hydrated. Seek medical attention if it worsens."
    elif "headache" in disease_desc:
        return "For headaches, rest in a quiet, dark room and stay hydrated."
    else:
        return "Please consult with a healthcare provider for personalized advice."

def groq_chatbot_response(user_message):
    """Get a response from the Groq LLaMA model."""
    chat_completion = client.chat.completions.create(
        messages=[{"role": "user", "content": user_message}],
        model="llama3-8b-8192",
    )
    return chat_completion.choices[0].message.content

# Updated video recommendation logic
def recommend_video(user_message):
    recommendations = {
        "headache": "https://www.youtube.com/embed/hZQbHz8_-Io",
        "fever": "https://www.youtube.com/embed/example_fever",  # Add actual links
        "cough": "https://www.youtube.com/embed/example_cough"
    }
    for key in recommendations:
        if key in user_message.lower():
            return recommendations[key]
    return "https://www.youtube.com/embed/example"  # Default demo link

# Updated product recommendation logic
def recommend_products(user_message):
    recommendations = {
        "headache": [{"name": "Headache Relief Pills", "link": "https://www.example.com/headache-relief"}],
        "fever": [{"name": "Fever Reducers", "link": "https://www.example.com/fever-reducers"}],
        "cough": [{"name": "Cough Syrup", "link": "https://www.example.com/cough-syrup"}]
    }
    for key in recommendations:
        if key in user_message.lower():
            return recommendations[key]
    return [{"name": "General Health Products", "link": "https://www.example.com/general-health"}]



# Home route
@app.route('/')
def index():
    return render_template('index.html')

# User details route
@app.route('/userdetails')
def userdetails():
    return render_template('user-details.html')

# Home page route
@app.route('/home')
def home():
    return render_template('home.html')

# Dashboard page route
@app.route('/dashboard')
def dashboard():
    return render_template('dashboard.html')

# Yoga page route
@app.route('/yoga')
def yoga():
    return render_template('yoga.html')

# Ayurvedic page route
@app.route('/ayurvedic')
def ayurvedic():
    return render_template('ayurveda.html')

# Support page route
@app.route('/support')
def support():
    return render_template('support.html')
@app.route('/chat-page', methods=['GET'])
def chat_page():
    return render_template('chat.html')
@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_message = data.get("message", "").lower()

    # Proactive initial greeting and health check
    if not user_message:
        # Log proactive greeting
        app.logger.info("Proactive greeting sent")
        return jsonify({
            "response": "Hello! How are you feeling today? Are you experiencing any discomfort or symptoms? Would you like help managing a particular condition?"
        })

    # Normal chatbot response logic
    response = groq_chatbot_response(user_message)
    app.logger.info(f"User message: {user_message}, Response: {response}")

    # Get video and product recommendations
    recommended_video = recommend_video(user_message)
    recommended_products = recommend_products(user_message)

    return jsonify({
        "response": response,
        "video_url": recommended_video,
        "product_links": recommended_products
    })

@app.route('/upload-image', methods=['POST'])
def upload_image():
    if 'image' not in request.files:
        return jsonify({"response": "No image uploaded."}), 400
    file = request.files['image']
    if file.filename == '':
        return jsonify({"response": "No selected file."}), 400
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)
        try:
            # Mock response for Chicken Pox
            disease_desc = "chicken pox"
            
            management_advice = "Stay hydrated, take anti-itch medication, and consult a doctor if symptoms worsen."
            response = f"Predicted condition: {disease_desc} . Management advice: {management_advice}"
            return jsonify({"response": response})
        except Exception as e:
            return jsonify({"response": f"Error processing image: {e}"}), 500
    return jsonify({"response": "Invalid file type."}), 400

if __name__ == '__main__':
    app.run(debug=True)